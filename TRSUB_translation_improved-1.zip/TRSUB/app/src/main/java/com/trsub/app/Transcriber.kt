package com.trsub.app

import kotlinx.coroutines.delay
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File

class Segment(val start: Double, val end: Double, val text: String)
class TranscribeResult(val language: String, val segments: List<Segment>)
class FatalApiError(message: String) : Exception(message)

/** يرسل الصوت إلى خدمة Whisper (متوافقة مع OpenAI، مثل Groq) ويرجع النص مع التوقيت. */
object Transcriber {

    private val junk = listOf(
        "thanks for watching", "thank you for watching", "subtitles by", "amara.org",
        "ご視聴ありがとうございました", "チャンネル登録", "字幕", "시청해 주셔서"
    )

    suspend fun transcribe(
        http: OkHttpClient, file: File, mime: String,
        baseUrl: String, model: String, key: String, language: String?
    ): TranscribeResult {
        for (attempt in 1..4) {
            val mb = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("file", file.name, file.asRequestBody(mime.toMediaType()))
                .addFormDataPart("model", model)
                .addFormDataPart("response_format", "verbose_json")
                .addFormDataPart("temperature", "0")
            if (!language.isNullOrBlank() && language != "auto") {
                mb.addFormDataPart("language", language)
            }
            val req = Request.Builder()
                .url(baseUrl.trimEnd('/') + "/audio/transcriptions")
                .header("Authorization", "Bearer $key")
                .post(mb.build())
                .build()

            val resp = http.newCall(req).execute()
            val code = resp.code
            val wait = Api.retryDelayMs(resp, attempt)
            val text = resp.body?.string() ?: ""
            resp.close()

            when {
                code in 200..299 -> return parse(text)
                code == 401 || code == 403 ->
                    throw FatalApiError("مفتاح API غير صحيح أو لا يملك صلاحية")
                code == 429 || code in 500..599 -> {
                    if (attempt < 4) delay(wait)
                    else throw Exception("الخدمة مشغولة حالياً، أعد المحاولة بعد قليل")
                }
                else -> throw Exception("خطأ من الخادم ($code): ${text.take(100)}")
            }
        }
        throw Exception("تعذّر الاتصال بالخدمة")
    }

    private fun parse(json: String): TranscribeResult {
        val o = JSONObject(json)
        val lang = o.optString("language", "")
        val arr = o.optJSONArray("segments")
        val list = ArrayList<Segment>()
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val s = arr.getJSONObject(i)
                val t = s.optString("text", "").trim()
                if (t.isEmpty()) continue
                if (t.none { it.isLetterOrDigit() }) continue // موسيقى أو رموز فقط

                val noSpeech = s.optDouble("no_speech_prob", 0.0)
                val logp = s.optDouble("avg_logprob", 0.0)
                val comp = s.optDouble("compression_ratio", 1.0)
                if (noSpeech > 0.6 && logp < -0.8) continue // غالباً صمت أو ضجيج
                if (logp < -1.6) continue                    // ثقة منخفضة جداً
                if (comp > 2.4) continue                     // تكرار (هلوسة)
                val low = t.lowercase()
                if (noSpeech > 0.3 && junk.any { low.contains(it) }) continue

                list.add(Segment(s.optDouble("start", 0.0), s.optDouble("end", 0.0), t))
            }
        }
        return TranscribeResult(lang, list)
    }
}
