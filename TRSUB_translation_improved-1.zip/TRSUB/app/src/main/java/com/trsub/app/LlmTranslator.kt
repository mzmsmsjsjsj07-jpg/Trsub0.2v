package com.trsub.app

import kotlinx.coroutines.delay
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/** ترجمة ذكية للحوار مع مراعاة السياق، متوافقة مع واجهة Groq/OpenAI. */
object LlmTranslator {

    private const val SYSTEM =
        "You are an expert Japanese-English to Arabic subtitle translator for anime, films and series. " +
        "Translate into fluent, idiomatic, natural Modern Standard Arabic that sounds like professionally edited subtitles. " +
        "Understand the meaning and intent; never translate word-for-word or preserve awkward source-language grammar. " +
        "SOURCE LANGUAGE is supplied by the user. Use it; do not guess another language. " +
        "For Japanese, infer omitted subjects and pronouns from context, distinguish politeness and honorifics, " +
        "and translate idioms by meaning. For English, preserve sarcasm, jokes, emotion and conversational intent. " +
        "Use previous_lines_for_context_only only to understand the current dialogue, continuity, relationships and names; " +
        "do not translate those context lines again. Keep names and terminology consistent, rendered in Arabic letters where appropriate. " +
        "Keep each subtitle concise and readable, normally one short sentence; preserve important meaning and tone. " +
        "Do not invent details, add explanations, or censor the meaning. Keep the same order and exactly one output item per input line. " +
        "Do not leave a spoken dialogue line empty. Return an empty string only for a clearly non-verbal sound effect or music label. " +
        "Reply with valid JSON only, in the form {\"translations\": [...]}, containing exactly as many strings " +
        "as lines_to_translate, in the same order. No markdown or commentary."

    suspend fun translate(
        http: OkHttpClient, baseUrl: String, model: String, key: String,
        sourceLang: String, lines: List<String>, context: List<String>
    ): List<String> {
        val user = JSONObject()
            .put("source_language", sourceLang)
            .put("target_language", "Arabic (Modern Standard Arabic)")
            .put("previous_lines_for_context_only", JSONArray(context))
            .put("lines_to_translate", JSONArray(lines))

        val bodyJson = JSONObject()
            .put("model", model)
            .put("temperature", 0.15)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put(
                "messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", SYSTEM))
                    .put(JSONObject().put("role", "user").put("content", user.toString()))
            )
        val bodyStr = bodyJson.toString()

        for (attempt in 1..4) {
            val req = Request.Builder()
                .url(baseUrl.trimEnd('/') + "/chat/completions")
                .header("Authorization", "Bearer $key")
                .post(bodyStr.toRequestBody("application/json".toMediaType()))
                .build()

            val resp = http.newCall(req).execute()
            val code = resp.code
            val wait = Api.retryDelayMs(resp, attempt)
            val text = resp.body?.string() ?: ""
            resp.close()

            when {
                code in 200..299 -> return parse(text, lines.size)
                code == 401 || code == 403 -> throw FatalApiError("مفتاح API غير صحيح أو لا يملك صلاحية")
                code == 429 || code in 500..599 -> {
                    if (attempt < 4) delay(wait)
                    else throw Exception("الخدمة مشغولة حالياً، أعد المحاولة بعد قليل")
                }
                else -> throw Exception("خطأ ($code): ${text.take(120)}")
            }
        }
        throw Exception("تعذّر الاتصال")
    }

    private fun parse(json: String, expected: Int): List<String> {
        val raw = JSONObject(json)
            .getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").optString("content", "").trim()
        if (raw.isEmpty()) throw Exception("رد فارغ من النموذج")
        val content = raw.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val arr = JSONObject(content).getJSONArray("translations")
        if (arr.length() != expected) throw Exception("عدد الأسطر المترجمة غير مطابق")
        val out = ArrayList<String>(expected)
        for (i in 0 until arr.length()) out.add(arr.optString(i, "").trim())
        return out
    }
}
